# Maths Tools Configurations

## Mathematica
- [`sudo bash install.sh`](http://support.wolfram.com/kb/12453): install mma

## SageMath

### [Install SageMath](http://askubuntu.com/a/599191/306000)

*Note:* It is about 3.8G.

```
sudo apt-add-repository -y ppa:aims/sagemath
sudo apt-get update
sudo apt-get install sagemath-upstream-binary
```
