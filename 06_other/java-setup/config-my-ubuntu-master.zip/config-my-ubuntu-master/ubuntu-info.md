# Basic Info about Your Ubuntu System

- [`lsb_release -a`](https://help.ubuntu.com/community/CheckingYourUbuntuVersion): checking your ubuntu version

  > Release: 16.10
  > Codename: yakkety

  For the full version number, following `System Settings | Details`.
