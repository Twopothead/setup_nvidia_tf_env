# config-my-ubuntu

This project maintains the configurations of my ubuntu system.

- ubuntu-config.md
- programming-environment
  - jdkinstaller.sh
  - developer-tools-config.md
    - Git
    - Gradle
    - Graphviz
    - PlantUML
    - VYM (Visual Your Mind)
  - editor-config.md
    - LaTeX
    - gVim (TODO)
  - ide-config.md
    - IntelliJ
    - Android Studio
    - Eclipse
  - math-tools-config.md
    - Mathematica (mma)
    - SageMath
  - programming-environment-config.md
    - Java and JDK
    - Python (TODO)
    - Haskell

Contact hengxin0912@gmail.com if you have trouble in following them.
